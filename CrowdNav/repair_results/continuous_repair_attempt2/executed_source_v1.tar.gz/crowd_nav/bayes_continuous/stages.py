"""Frozen five-human development stages; no high-density model selection."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from stable_baselines3.common.utils import obs_as_tensor
from crowd_nav.bayes_continuous.environment import BeliefEnv
from crowd_nav.bayes_continuous.algorithm import BayesSetTD3, CostReplay
from crowd_nav.bayes_continuous.network import SetEncoder
from crowd_nav.bayes_continuous.train_smoke import stack_obs
from crowd_nav.gdbn import GNG, GDBN


def episodes(params, count, offset, actor=None, collect=False):
    env = BeliefEnv(params, seed=2407)
    records, trajectories, raw = [], [], []
    for episode in range(count):
        obs, _ = env.reset(options={'layout_seed': offset+episode, 'test_case': episode,
                                    'profile': 'nominal'})
        rows, states = [], []
        for _ in range(140):
            states.append(np.array([[h.px, h.py, h.vx, h.vy, h.radius] for h in env.world.env.humans]))
            action = env.expert_action() if actor is None else actor.predict(obs, deterministic=True)[0]
            nxt, reward, done, _, info = env.step(action)
            if collect:
                rows.append(dict(observation=obs, next_observation=nxt, action=action,
                                 reward=reward, done=done, collision_cost=info['collision_cost']))
            obs = nxt
            if done:
                records.append(info['episode_result'])
                break
        else:
            raise AssertionError('140-step terminal contract failed')
        trajectories.append(rows)
        raw.append(np.asarray(states))
        if episode % 20 == 19:
            print('episodes', offset, episode+1, flush=True)
    env.close()
    return records, trajectories, raw


def receipt(records):
    return dict(episodes=len(records), success_rate=np.mean([r['outcome']=='success' for r in records]),
                collision_rate=np.mean([r['outcome']=='collision' for r in records]))


def fit_world_models(raw, out):
    # Both mode discovery and linear dynamics use absolute world coordinates.
    features = np.concatenate([x.reshape(-1, 5) for x in raw])
    np.random.seed(2407)
    gng = GNG(k_target=3)
    gng._feat_mean = features.mean(0)
    gng._feat_std = features.std(0)+1e-6
    standardized = (features-gng._feat_mean)/gng._feat_std
    rng = np.random.default_rng(2407)
    gng.nodes = standardized[rng.choice(len(features), 2, replace=False)].copy()
    gng.errors = np.zeros(2)
    for _ in range(3):
        for i in rng.permutation(len(features)):
            gng._gng_step(standardized[i])
    if gng.n_modes != 3:
        raise RuntimeError('Mode fitting did not produce three supported modes')
    pairs = [[] for _ in range(3)]
    counts = np.ones((3, 3))
    for trajectory in raw:
        for t in range(len(trajectory)-1):
            for i in range(5):
                x, y = trajectory[t, i], trajectory[t+1, i]
                k, j = gng.assign_mode(x), gng.assign_mode(y)
                pairs[k].append((x[:4], y[:4]))
                counts[k, j] += 1
    model = GDBN(3)
    model.Pi = counts/counts.sum(1, keepdims=True)
    for k in range(3):
        if len(pairs[k]) < 100:
            raise RuntimeError('Insufficient five-human training support')
        x, y = np.asarray(pairs[k]).transpose(1, 0, 2)
        model.A[k] = np.linalg.solve(x.T@x+1e-3*np.eye(4), x.T@y).T
        residual = y-x@model.A[k].T
        model.Q[k] = residual.T@residual/len(x)+1e-4*np.eye(4)
    out.mkdir()
    gng.save(str(out/'gng.npz'))
    model.save(str(out/'gdbn.npz'))
    (out/'provenance.json').write_text(json.dumps(dict(
        scenario='baseline_circle', humans=5, profile='nominal', layout_offset=520000,
        mode_features='world px,py,vx,vy,radius', dynamics='world px,py,vx,vy',
        coordinate_contract='No robot-relative feature assignment on this inference path',
        mode_support=[len(x) for x in pairs], model_R='fixed 0.01 I; not calibrated sensor noise',
        raw_sha256=hashlib.sha256(b''.join(x.tobytes() for x in raw)).hexdigest()), indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--params', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(exist_ok=False)
    torch.set_num_threads(1)
    torch.cuda.set_per_process_memory_fraction(.2)
    result = {'protocol': 'Five-human development only, fixed stages, seed 2407',
              'gate': {'episodes':100, 'min_success':.9, 'max_collision':.02},
              'bc_updates':3000, 'rl_started':False}
    def save():
        (args.out/'results.json').write_text(json.dumps(result, indent=2))
    records, _, _ = episodes(args.params, 100, 510000)
    result['teacher_records'] = records
    result['teacher'] = receipt(records)
    save()
    # Always retain the finite development collection, even if teacher qualification fails.
    records, _, raw = episodes(args.params, 200, 520000)
    fit_world_models(raw, args.out/'fitted_params')
    torch.save(raw, args.out/'fit_trajectories.pt')
    params = args.out/'fitted_params'
    # Replay the fixed training layouts with the newly fitted filter, not stale beliefs.
    records, trajectories, _ = episodes(params, 200, 520000, collect=True)
    torch.save(dict(records=records, trajectories=trajectories), args.out/'collection.pt')
    good = [row for record, rows in zip(records, trajectories) if record['outcome']=='success' for row in rows]
    result['accepted_bc_episodes'] = sum(r['outcome']=='success' for r in records)
    result['rejected_bc_episodes'] = 200-result['accepted_bc_episodes']
    result['collection_records'] = records
    env = BeliefEnv(params)
    model = BayesSetTD3('MultiInputPolicy', env, replay_buffer_class=CostReplay,
        buffer_size=50000, learning_rate=3e-4, batch_size=128, seed=2407, device='cuda',
        policy_kwargs=dict(features_extractor_class=SetEncoder, net_arch=[96,96], share_features_extractor=False))
    observations = stack_obs([r['observation'] for r in good])
    actions = model.policy.scale_action(np.stack([r['action'] for r in good])).astype(np.float32)
    rng = np.random.default_rng(2407)
    for _ in range(3000):
        idx = rng.integers(len(good), size=128)
        batch = obs_as_tensor({k:v[idx] for k,v in observations.items()}, model.device)
        loss = torch.nn.functional.mse_loss(model.actor(batch), torch.as_tensor(actions[idx], device=model.device))
        model.actor.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.actor.parameters(), 10.)
        model.actor.optimizer.step()
    model.actor_target.load_state_dict(model.actor.state_dict())
    model.save(args.out/'bc_only')
    records, _, _ = episodes(params, 100, 530000, model)
    result['bc_records'], result['bc'] = records, receipt(records)
    save()
    # Critic pretraining is allowed for diagnosis, but actor remains frozen.
    for rows in trajectories:
        for row in rows:
            model.replay_buffer.add({k:v[None] for k,v in row['observation'].items()},
                {k:v[None] for k,v in row['next_observation'].items()},
                model.policy.scale_action(row['action'][None]), np.array([row['reward']]),
                np.array([row['done']]), [{'collision_cost':row['collision_cost']}])
    before = {k:v.clone() for k,v in model.actor.state_dict().items()}
    model.train(1000, 128)
    assert all(torch.equal(before[k], v) for k,v in model.actor.state_dict().items())
    result['warmup_actor_unchanged'] = True
    result['warmup_updates'] = model.warmup_updates
    (args.out/'losses.json').write_text(json.dumps(model.loss_history))
    model.save(args.out/'critic_warmup')
    try:
        if result['teacher']['success_rate'] < .9 or result['teacher']['collision_rate'] > .02:
            raise RuntimeError('Teacher gate failed')
        model.enable_actor(result['bc'])
    except RuntimeError as exc:
        result['decision'] = 'RL blocked: '+str(exc)
    else:
        # Separate explicit learner entry; never silently launch a long run here.
        result['decision'] = 'Teacher/BC/count warm-up gates passed; critic calibration still requires validation'
    save()
    print(result['teacher'], result['bc'], result['decision'], flush=True)


if __name__ == '__main__':
    main()
